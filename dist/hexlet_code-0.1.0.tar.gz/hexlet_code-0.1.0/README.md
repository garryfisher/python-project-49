### Hexlet tests and linter status:
[![Actions Status](https://github.com/garryfisher/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/garryfisher/python-project-49/actions)
###codeclimate
[![Maintainability](https://api.codeclimate.com/v1/badges/d11f07f84f08016e3ab7/maintainability)](https://codeclimate.com/github/garryfisher/python-project-49/maintainability)

<a href="https://asciinema.org/a/Cpev1zPiABT5hpm8m12uZzCch" target="_blank"><img src="https://asciinema.org/a/Cpev1zPiABT5hpm8m12uZzCch.svg" /></a>
