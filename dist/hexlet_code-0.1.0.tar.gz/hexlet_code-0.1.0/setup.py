# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First hexlet project',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/garryfisher/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/garryfisher/python-project-49/actions)\n###codeclimate\n[![Maintainability](https://api.codeclimate.com/v1/badges/d11f07f84f08016e3ab7/maintainability)](https://codeclimate.com/github/garryfisher/python-project-49/maintainability)\n\nBrain Games. First project in <a href="https://ru.hexlet.io/programs/python">Hexlet</a> paython developer course.\n\nGame: "Checking a number for even"\n<a href="https://asciinema.org/a/8RnjhldmRYb1lSGyotfp3IGuj" target="_blank"><img src="https://asciinema.org/a/8RnjhldmRYb1lSGyotfp3IGuj.svg" /></a>\n\nGame: "Calculator"\n<a href="https://asciinema.org/a/1ZW16LWoLUqiF0AaGM2Na73Xk" target="_blank"><img src="https://asciinema.org/a/1ZW16LWoLUqiF0AaGM2Na73Xk.svg" /></a>\n\nGame: "Find the greatest common divisor"\n<a href="https://asciinema.org/a/b4UBJARlC3Rb2bKq8nwbZT1rY" target="_blank"><img src="https://asciinema.org/a/b4UBJARlC3Rb2bKq8nwbZT1rY.svg" /></a>\n\nGame: "Arithmetic progression"\n<a href="https://asciinema.org/a/OIohdjM1sVPdLlQQ10S4CxLsO" target="_blank"><img src="https://asciinema.org/a/OIohdjM1sVPdLlQQ10S4CxLsO.svg" /></a>\n\nGame: "Is it a prime number?"\n<a href="https://asciinema.org/a/Pr1CXq6iEuNt2NcFRsT8BbG72" target="_blank"><img src="https://asciinema.org/a/Pr1CXq6iEuNt2NcFRsT8BbG72.svg" /></a>\n\n',
    'author': 'Gennady Vinogradov',
    'author_email': 'gwinogradow@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/garryfisher/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
