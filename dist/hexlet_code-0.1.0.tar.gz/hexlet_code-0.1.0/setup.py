# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'First hexlet project',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/garryfisher/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/garryfisher/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/d11f07f84f08016e3ab7/maintainability)](https://codeclimate.com/github/garryfisher/python-project-49/maintainability)\n\n<h3>Install.</h3>\n\n1. <b>Clone from github:</b><br>\n<i>git clone https://github.com/garryfisher/python-project-49.git</i>\n\n<a href="https://asciinema.org/a/Wy3lPogvQaqMOB1rsZaQHVEMQ" target="_blank"><img src="https://asciinema.org/a/Wy3lPogvQaqMOB1rsZaQHVEMQ.svg" /></a>\n\n2. <b>Go to the directory "python-project-49" and execute the commands:</b><br>\n<i>cd python-project-49</i><br>\n<i>make install</i><br>\n<i>make build</i><br>\n<i>make packet-install</i>\n\n<a href="https://asciinema.org/a/jSp9WgD8qiBAtCrak9tarwLPW" target="_blank"><img src="https://asciinema.org/a/jSp9WgD8qiBAtCrak9tarwLPW.svg" /></a>\n\n<h3>Game description. To start the corresponding game, execute the commands:</h3>\n\n<b>Game: "Checking a number for even"</b><br>\n<i>brain-even</i>\n\n<a href="https://asciinema.org/a/8RnjhldmRYb1lSGyotfp3IGuj" target="_blank"><img src="https://asciinema.org/a/8RnjhldmRYb1lSGyotfp3IGuj.svg" /></a>\n\n<b>Game: "Calculator"</b><br>\n<i>brain-calc</i>\n\n<a href="https://asciinema.org/a/1ZW16LWoLUqiF0AaGM2Na73Xk" target="_blank"><img src="https://asciinema.org/a/1ZW16LWoLUqiF0AaGM2Na73Xk.svg" /></a>\n\n<b>Game: "Find the greatest common divisor"</b><br>\n<i>brain-gcd</i>\n\n<a href="https://asciinema.org/a/b4UBJARlC3Rb2bKq8nwbZT1rY" target="_blank"><img src="https://asciinema.org/a/b4UBJARlC3Rb2bKq8nwbZT1rY.svg" /></a>\n\n<b>Game: "Arithmetic progression"</b><br>\n<i>brain-progression</i>\n<a href="https://asciinema.org/a/OIohdjM1sVPdLlQQ10S4CxLsO" target="_blank"><img src="https://asciinema.org/a/OIohdjM1sVPdLlQQ10S4CxLsO.svg" /></a>\n\n<b>Game: "Is it a prime number?"</b><br>\n<i>brain-prime</i>\n\n<a href="https://asciinema.org/a/Pr1CXq6iEuNt2NcFRsT8BbG72" target="_blank"><img src="https://asciinema.org/a/Pr1CXq6iEuNt2NcFRsT8BbG72.svg" /></a>\n\n',
    'author': 'Gennady Vinogradov',
    'author_email': 'gwinogradow@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/garryfisher/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
